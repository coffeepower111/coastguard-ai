# AI 해양치안 신고·현장대응 지원시스템

## 실행 (로컬/서버 공통)
1. Node.js 20.12 이상 설치
2. `.env.example`을 `.env`로 복사하고 `ANTHROPIC_API_KEY` 입력
3. `node server.js` → http://localhost:3000

API 키가 없거나 AI 호출이 실패하면 기존 규칙 기반 분석으로 자동 대체됩니다.

## 서버 배포
- **Render / Railway / Fly.io**: 이 폴더를 GitHub에 올리고 새 Web Service 생성 → Start Command `node server.js` → 환경변수(`ANTHROPIC_API_KEY`, `ACCESS_CODE`) 등록
- **Docker**: `docker build -t maritime-ai . && docker run -p 3000:3000 --env-file .env maritime-ai`
- **사내 서버**: `node server.js`를 pm2 등으로 상시 실행, 앞단에 HTTPS(nginx 등) 적용

## 확인
`/api/health` 에서 `"ai": true` 이면 AI 연결 완료.

## 보안 주의
- API 키는 서버 `.env`에만 두고 GitHub에 올리지 마세요(.gitignore 포함됨).
- 인터넷에 공개할 때는 반드시 `ACCESS_CODE`를 설정하세요.
- 실제 신고내용·개인정보는 외부 AI API로 전송됩니다. 기관 보안 승인 후 사용하세요.
